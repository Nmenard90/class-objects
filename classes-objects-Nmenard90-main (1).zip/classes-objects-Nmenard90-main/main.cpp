/*
 * Nicholas Menard
 * Assignment 3
 * Purpose of this file - Main Function for Testing
 * This File contains the main function to demonstrate the functionalities of Circle and Sphere classes.
 * Includes automated tests for various methods of Circle and Sphere objects.
 */
#include "main.h"

int main(int argc, char** argv) {
/*
 * Main Function
 * Entry point of the application. This function demonstrates the usage of Circle and Sphere classes.
 * It creates instances of Circle and Sphere, both with default and parameterized constructors, 
 * and then displays their properties using the displayCircle and displaySphere functions.
 *
 * @param argc : The count of command-line arguments.
 * @param argv : An array of command-line arguments.
 *
 * @return int : Returns 0 indicating successful execution.
 */

    Circle myCircle1;
    Circle myCircle2(11);

    Sphere mySphere1;
    Sphere mySphere2(11);

    displayCircle(&myCircle1);
    displayCircle(&myCircle2);

    displaySphere(&mySphere1);
    displaySphere(&mySphere2);

    return 0;
}
