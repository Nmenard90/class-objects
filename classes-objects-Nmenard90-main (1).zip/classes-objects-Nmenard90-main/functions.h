/*
 * Nicholas Menard
 * Assignment 3
 * Function Declarations Header
 * This file Contains declarations for utility functions to display properties of Circle and Sphere objects.
 * Includes displayCircle and displaySphere function declarations.
 */
 
#ifndef CIRCLES_FUNCTIONS_H
#define CIRCLES_FUNCTIONS_H

#include <iostream> // for cout
#include <iomanip> // for setting precision of out statments. If a number has a repeating value I don't want it to print a million numbers.
                  // additionally standards for most math only go up to 4 decimal places, so I did five so the user can choose to round up or down.

#include "sphere.h" // This includes the Sphere class

// Function prototypes 
void displayCircle(Circle*);
void displaySphere(Sphere*);

#endif //CIRCLES_FUNCTIONS_H
