/*********************
Nicholas Menard
Assignment: 3
 This file implements the methods of the Sphere class, including the constructors, destructor, and methods 
for calculating the volume and surface area of a sphere. 
It also includes an overridden getArea method from the Circle class for sphere-specific area calculation.

**********************/

#include "sphere.h"

Sphere::Sphere() : Circle(MIN_RADIUS) {

/**
 * Default constructor.
 * Initializes the sphere with the minimum radius (inherited from Circle).
 */

}
Sphere::Sphere(double r) : Circle(r) {

/**
 * Constructor with radius parameter.
 * Initializes the sphere with the specified radius.
 * 
 * @param r : the initial radius of the sphere
 */

}

Sphere::~Sphere() {

 /**
 * Destructor.
 */
 // No dynamic memory allocation or special cleanup required
 
}



double Sphere::getVolume() {
 /**
 * Calculate and return the volume of the sphere.
 * 
 * @return the volume of the sphere
 */

    return (4.0/3.0) * PI * radius * radius * radius;
}


double Sphere::getSurfaceArea() {
 /**
 * Calculate and return the surface area of the sphere.
 * Overrides the getArea method from the Circle class.
 * 
 * @return the surface area of the sphere
 */
    return 4 * PI * radius * radius;
}
