/*
 * Name: Nicholas Menard
 * Assignment: 3
 * This file includes Function Implementations
 * It implements functions to display the properties of Circle and Sphere objects.
 * Includes the implementation of displayCircle and displaySphere functions.
 */
 #include "functions.h"


void displayCircle(Circle *myCircle){
 /******************************************************************************************
 * This function displays the circle properties and
 * Outputs the properties of a Circle object to the standard output.
 * Displays the radius, area, and circumference of the circle.
 *
 * @param myCircle : A pointer to the Circle object whose properties are to be displayed.
 *
 * @return void
 ********************************************************************************************/
    std::cout << std::fixed << std::setprecision(5); // Set precision to 5 decimal places
    std::cout << "Radius: " << myCircle->getRadius() << std::endl;
    std::cout << "Area: " << myCircle->getArea() << std::endl;
    std::cout << "Circumference: " << myCircle->getCircumference() << std::endl;
    std::cout << std::endl;
}

void displaySphere(Sphere *mySphere){
 /***************************************************************************************
 * This function displays Sphere Properties by
 * outputting the properties of a Sphere object to the standard output.
 * Displays the radius, volume, and surface area of the sphere.
 *
 * @param mySphere : A pointer to the Sphere object whose properties are to be displayed.
 *
 * @return void
 ***************************************************************************************/
    std::cout << std::fixed << std::setprecision(5); // Set precision to 5 decimal places
    std::cout << "Radius: " << mySphere->getRadius() << std::endl;
    std::cout << "Volume: " << mySphere->getVolume() << std::endl;
    std::cout << "Surface Area: " << mySphere->getSurfaceArea() << std::endl;
    std::cout << std::endl;
}
