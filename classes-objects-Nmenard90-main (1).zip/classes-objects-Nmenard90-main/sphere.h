/*********************
Name: Nicholas Menard
Assignment: 3
This file defines the Sphere class, which is an extension of the Circle class. 
It includes the declaration of the Sphere class with its constructor, destructor, and member functions 
for calculating the volume and surface area of a sphere. 
Additionally, it overrides the getArea method from the Circle class to provide sphere-specific functionality.
**********************/

#ifndef CLASSES_SPHERE_H
#define CLASSES_SPHERE_H

#include "circle.h" // This includes the Circle class


class Sphere : public Circle {
public:

/*********************************************
 This class defines a Sphere, extending the Circle class. It includes two constructors
 to initialize the sphere with a default radius or a specified radius,
 a destructor, and methods to calculate the volume and surface area of the sphere.
 Additionally, it overrides the getArea method from the Circle class to provide 
 sphere-specific functionality for calculating the surface area.

 @attrib double radius : inherited from the Circle class, represents the radius of the sphere
 *********************************************/

/**********************
Constructors/Destructor
 ***********************/
    Sphere();
    Sphere(double radius);
    ~Sphere();

/**********************
Getters
***********************/
    double getVolume();
    double getSurfaceArea(); // overloads the getarea  function in the Circle class
                            // to calculate the surface area of a sphere instead

/**********************
Setters
***********************/

// NONE //

};

#endif //CLASSES_SPHERE_H
