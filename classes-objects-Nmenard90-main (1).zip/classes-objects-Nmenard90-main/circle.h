/*********************
Name: Nicholas Menard
Assignment: 3
Purpose of the file: This file defines the Circle class. 
It includes the declaration of the Circle class with its constructor, destructor, and member functions 
for setting and getting the radius, and for calculating the area and circumference of a circle. 
The Circle class allows for the representation of a circle with a specified radius, providing functionality to calculate and retrieve its area
 and circumference, along with setting or getting its radius.
***************************/


#ifndef CLASSES_CIRCLE_H
#define CLASSES_CIRCLE_H

#define MIN_RADIUS 0 // set minimum radius to 0 if no radius given. 

const double PI = 3.14159; // set preicion of Pi to 5 decimals to keep consistant. 

class Circle {
/*********************************************
 This class defines a Circle. It includes two constructors
to initialize the circle with a default radius or a specified radius,
 a destructor, and methods to set and get the radius,
calculate the area, and calculate the circumference of the circle.

@attrib double radius : the radius of the circle
*********************************************/
    

public:

/**********************
Constructors/Destructor
***********************/
    
    Circle();
    Circle(double radius);
    ~Circle();
   
/**********************
Getters
***********************/
    
    double getRadius();
    double getArea();
    double getCircumference();
    
/**********************
Setters
***********************/
    void setRadius(double radius);


protected:
    double radius; /**< radius of the circle */
};

#endif //CLASSES_CIRCLE_H