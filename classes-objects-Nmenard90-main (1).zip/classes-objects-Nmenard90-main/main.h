/*
 * Nicholas Menard
 * Assignment 3
 * Main Header File
 * This file contains the Central header file for the application, including necessary directives.
 * Includes the headers for the Sphere class sphere.h and the function declarations (functions.h).
 * Facilitates the inclusion of all required headers in main.cpp.
 */

#ifndef MAIN_CLASSES_H
#define MAIN_CLASSES_H

#include "sphere.h" // This includes the Sphere class
#include "functions.h" // This includes the function prototypes
#include <iostream> // for cout

#endif // MAIN_CLASSES_H
