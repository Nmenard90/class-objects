/*********************
Name: Nicholas Menard
Assignment: 3
Purpose of this file: This file implements the methods defined in the Circle class. 
It includes the constructors, destructor, and the implementation of methods for 
getting the radius, calculating the area and circumference, and setting the radius of a circle
**********************/

#include "circle.h"
Circle::Circle() {
    setRadius(MIN_RADIUS);
}
/**
 * Default constructor.
 * Initializes the circle with the minimum radius.
 */


Circle::Circle(double r) {
    setRadius(r);
/**
 * Constructor with radius parameter.
 * Initializes the circle with the specified radius.
 * 
 * @param r : the initial radius of the circle
 */

}
Circle::~Circle() {
/**
 * Destructor.
 */    

}


double Circle::getRadius() {
    return radius;
/**
 * Get the radius of the circle.
 * 
 * @return the current radius of the circle
 */

}
double Circle::getArea() {
    
/**
 * Calculate and return the area of the circle.
 * 
 * @return the area of the circle
 */
    return PI * radius * radius;
}

double Circle::getCircumference() {
    
/**
 * Calculate and return the circumference of the circle.
 * 
 * @return the circumference of the circle
 */
   
    return 2 * PI * radius;
}

void Circle::setRadius(double r){

/**
 * Set the radius of the circle.
 * If the given radius is greater than the minimum radius, it sets the radius to the given value.
 * Otherwise, it sets the radius to the minimum radius.
 * 
 * @param r : the new radius of the circle
 */
    
    if (r > MIN_RADIUS) {
        radius = r;
    } else {
        radius = MIN_RADIUS;
    }
}
