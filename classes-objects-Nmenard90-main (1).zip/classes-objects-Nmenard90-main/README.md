Circle and Sphere Calculator. 

This application is a refresher of Object-Oriented Programming in C++. It includes classes for representing circles and spheres, allowing users to calculate properties like area, volume, and circumference.

-----------------------------------------------------

Description 

The project consists of two primary classes:

Circle: Calculates the area and circumference of a circle based on its radius.
Sphere: Inherits from Circle and adds the functionality to calculate the volume and surface area of a sphere.

-----------------------------------------------------

Dependencies

g++ complier for c++

Installing and Running
g++ -I ./ *.cpp to compile all the files
./a.exe to run the application 

-----------------------------------------------------

Usage

Upon running, the program will display the properties of default and parameterized circles and spheres:

It creates circles and spheres with default and specified radiuses...Radii???. Multiple radius?
It then prints out the radius, area, and circumference for circles, and the radius, volume, and surface area for spheres.

-----------------------------------------------------

Authors 
Nicholas Menard


